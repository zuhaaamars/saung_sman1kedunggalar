import React, { useState } from 'react';
import { Layers, Calendar, Search, FileSpreadsheet, CheckCircle, AlertTriangle, XCircle, Info } from 'lucide-react';

const RekapHarian = () => {
  // ==========================================
  // SIMULASI DATA FILTER DROPDOWN
  // ==========================================
  const listKelas = ['X-RPL 1', 'XI-RPL 1', 'XII-RPL 1'];
  
  // Ambil tanggal hari ini format YYYY-MM-DD untuk default input date
  const hariIni = new Date().toISOString().split('T')[0];

  // ==========================================
  // STATE MANAGEMENT
  // ==========================================
  const [selectedKelas, setSelectedKelas] = useState('XI-RPL 1');
  const [selectedTanggal, setSelectedTanggal] = useState(hariIni);

  // Simulasi data kehadiran harian siswa (Satu status untuk satu hari penuh)
  const [dataSiswaHarian, setDataSiswaHarian] = useState([
    { id: 1, nis: '20260101', nama: 'Achmad Rafli', status: 'Hadir', keterangan: 'Masuk Pagi (06:45)' },
    { id: 2, nis: '20260102', nama: 'Aditya Pramana', status: 'Hadir', keterangan: 'Masuk Pagi (06:55)' },
    { id: 3, nis: '20260103', nama: 'Bunga Lestari', status: 'Izin', keterangan: 'Surat Acara Keluarga' },
    { id: 4, nis: '20260104', nama: 'Citra Kirana', status: 'Alpa', keterangan: 'Tanpa Keterangan' },
    { id: 5, nis: '20260105', nama: 'Dimas Anggara', status: 'Sakit', keterangan: 'Surat Dokter (Demam)' },
    { id: 6, nis: '20260106', nama: 'Farhan Maulana', status: 'Hadir', keterangan: 'Masuk Pagi (06:50)' },
    { id: 7, nis: '20260107', nama: 'Gita Gutawa', status: 'Hadir', keterangan: 'Masuk Pagi (07:00)' }
  ]);

  // ==========================================
  // LOGIKA AKSI KOREKSI STATUS GURU PIKET
  // ==========================================
  const handleKoreksiStatusHarian = (id, statusBaru) => {
    setDataSiswaHarian(prevData =>
      prevData.map(siswa => {
        if (siswa.id === id) {
          let ket = 'Koreksi Guru Piket';
          if (statusBaru === 'Hadir') ket = 'Hadir Manual';
          if (statusBaru === 'Izin') ket = 'Izin (Ada Surat)';
          if (statusBaru === 'Sakit') ket = 'Sakit (Ada Surat/Kabar)';
          if (statusBaru === 'Alpa') ket = 'Tanpa Keterangan';

          return { ...siswa, status: statusBaru, keterangan: ket };
        }
        return siswa;
      })
    );
  };

  // ==========================================
  // PERHITUNGAN STATISTIK HARIAN
  // ==========================================
  const totalSiswa = dataSiswaHarian.length;
  const jumlahHadir = dataSiswaHarian.filter(s => s.status === 'Hadir').length;
  const jumlahIzin = dataSiswaHarian.filter(s => s.status === 'Izin').length;
  const jumlahSakit = dataSiswaHarian.filter(s => s.status === 'Sakit').length;
  const jumlahAlpa = dataSiswaHarian.filter(s => s.status === 'Alpa').length;

  return (
    <div className="max-w-5xl mx-auto font-sans pb-12">
      
      {/* HEADER HALAMAN */}
      <div className="mb-6">
        <h1 className="text-2xl font-black text-[#3e2723] uppercase">Rekap Presensi Harian Sekolah</h1>
        <p className="text-gray-500 text-sm">Dashboard Guru Piket / Wali Kelas untuk memantau status kehadiran siswa per hari.</p>
      </div>

      {/* FILTER PANEL (TANPA MAPEL) */}
      <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Pilih Tanggal</label>
          <div className="relative">
            <input
              type="date"
              value={selectedTanggal}
              onChange={(e) => setSelectedTanggal(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-xs font-bold bg-white text-gray-700 focus:outline-none focus:border-[#E67E22]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Rumpun Kelas</label>
          <div className="relative">
            <select
              value={selectedKelas}
              onChange={(e) => setSelectedKelas(e.target.value)}
              className="w-full px-3 py-2.5 pl-9 border border-gray-200 rounded-xl text-xs font-bold bg-white text-gray-700 focus:outline-none focus:border-[#E67E22] appearance-none"
            >
              {listKelas.map((k, i) => <option key={i} value={k}>{k}</option>)}
            </select>
            <Layers size={14} className="absolute left-3 top-3.5 text-gray-400" />
          </div>
        </div>
      </div>

      {/* RINGKASAN ANGKA STATISTIK */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-6">
        <div className="bg-white p-4 rounded-xl border border-gray-100 text-center">
          <p className="text-[10px] text-gray-400 font-bold uppercase">Total Siswa</p>
          <p className="text-xl font-black text-[#3e2723]">{totalSiswa}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 text-center border-b-2 border-b-emerald-500">
          <p className="text-[10px] text-emerald-600 font-bold uppercase">Total Hadir</p>
          <p className="text-xl font-black text-emerald-600">{jumlahHadir}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 text-center border-b-2 border-b-amber-500">
          <p className="text-[10px] text-amber-600 font-bold uppercase">Total Izin</p>
          <p className="text-xl font-black text-amber-600">{jumlahIzin}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 text-center border-b-2 border-b-blue-500">
          <p className="text-[10px] text-blue-600 font-bold uppercase">Total Sakit</p>
          <p className="text-xl font-black text-blue-600">{jumlahSakit}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 text-center border-b-2 border-b-red-500 col-span-2 sm:col-span-1">
          <p className="text-[10px] text-red-500 font-bold uppercase">Total Alpa</p>
          <p className="text-xl font-black text-red-500">{jumlahAlpa}</p>
        </div>
      </div>

      {/* TABEL DATA PRESENSI HARIAN */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-sm font-black text-[#3e2723] uppercase tracking-wider flex items-center gap-2">
            <FileSpreadsheet size={16} className="text-[#E67E22]" /> Lembar Kehadiran Harian Kelas
          </h2>
          <button className="text-[11px] font-bold bg-[#3e2723] hover:bg-[#52332c] text-white px-3 py-1.5 rounded-lg transition-all shadow-xs">
            📥 Export Excel
          </button>
        </div>

        <div className="overflow-x-auto rounded-xl border border-gray-100">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-500 font-bold text-xs uppercase tracking-wider border-b border-gray-100">
                <th className="p-4 w-24 text-center">NIS</th>
                <th className="p-4">Nama Lengkap Siswa</th>
                <th className="p-4 text-center">Status Harian</th>
                <th className="p-4">Keterangan Log</th>
                <th className="p-4 text-center w-56">Aksi Guru Piket</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm text-gray-700">
              {dataSiswaHarian.map((siswa) => (
                <tr key={siswa.id} className="hover:bg-gray-50/40 transition-all">
                  
                  {/* NIS */}
                  <td className="p-4 text-center font-mono text-xs font-bold text-gray-400">{siswa.nis}</td>
                  
                  {/* NAMA */}
                  <td className="p-4 font-bold text-[#3e2723]">{siswa.nama}</td>
                  
                  {/* STATUS */}
                  <td className="p-4 text-center">
                    <span className={`text-[9px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider inline-flex items-center gap-1 ${
                      siswa.status === 'Hadir' ? 'bg-emerald-50 text-emerald-600' :
                      siswa.status === 'Izin' ? 'bg-amber-50 text-amber-600' :
                      siswa.status === 'Sakit' ? 'bg-blue-50 text-blue-600' : 'bg-red-50 text-red-500'
                    }`}>
                      {siswa.status === 'Hadir' && <CheckCircle size={10} />}
                      {siswa.status === 'Izin' && <Info size={10} />}
                      {siswa.status === 'Sakit' && <AlertTriangle size={10} />}
                      {siswa.status === 'Alpa' && <XCircle size={10} />}
                      {siswa.status}
                    </span>
                  </td>

                  {/* KETERANGAN */}
                  <td className="p-4 text-xs font-medium text-gray-500 italic">{siswa.keterangan}</td>

                  {/* TOMBOL AKSI PIKET */}
                  <td className="p-4 text-center">
                    <div className="inline-flex rounded-xl border border-gray-200 p-1 bg-gray-50 gap-1.5">
                      <button
                        onClick={() => handleKoreksiStatusHarian(siswa.id, 'Hadir')}
                        className={`w-7 h-7 text-[11px] font-black rounded-lg transition-all ${siswa.status === 'Hadir' ? 'bg-emerald-500 text-white shadow-xs' : 'text-gray-400 hover:bg-gray-200 hover:text-gray-700'}`}
                      >
                        H
                      </button>
                      <button
                        onClick={() => handleKoreksiStatusHarian(siswa.id, 'Izin')}
                        className={`w-7 h-7 text-[11px] font-black rounded-lg transition-all ${siswa.status === 'Izin' ? 'bg-amber-500 text-white shadow-xs' : 'text-gray-400 hover:bg-gray-200 hover:text-gray-700'}`}
                      >
                        I
                      </button>
                      <button
                        onClick={() => handleKoreksiStatusHarian(siswa.id, 'Sakit')}
                        className={`w-7 h-7 text-[11px] font-black rounded-lg transition-all ${siswa.status === 'Sakit' ? 'bg-blue-500 text-white shadow-xs' : 'text-gray-400 hover:bg-gray-200 hover:text-gray-700'}`}
                      >
                        S
                      </button>
                      <button
                        onClick={() => handleKoreksiStatusHarian(siswa.id, 'Alpa')}
                        className={`w-7 h-7 text-[11px] font-black rounded-lg transition-all ${siswa.status === 'Alpa' ? 'bg-red-500 text-white shadow-xs' : 'text-gray-400 hover:bg-gray-200 hover:text-gray-700'}`}
                      >
                        A
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

export default RekapHarian;