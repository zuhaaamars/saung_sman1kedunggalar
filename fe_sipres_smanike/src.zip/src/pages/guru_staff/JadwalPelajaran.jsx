import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Plus, Edit2, Trash2, Calendar, 
  Layers, Clock, RefreshCcw, AlertTriangle, X 
} from 'lucide-react';

const JadwalPelajaran = () => {
  // =========================
  // STATE MANAGEMENT
  // =========================
  const [jadwalList, setJadwalList] = useState([]);
  const [kelasOptions, setKelasOptions] = useState(['XI-RPL 1', 'XI-RPL 2', 'X-RPL 1', 'XII-RPL 1']); // Opsi Filter Kelas
  
  // State Filter Utama di Tabel
  const [selectedKelasFilter, setSelectedKelasFilter] = useState('Semua');
  const [loading, setLoading] = useState(false);

  // State Modal Form (Tambah / Edit)
  const [showModal, setShowModal] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [formData, setFormData] = useState({
    id_kelas: '',
    id_user: '', // ID/Nama Guru
    id_mapel: '', // ID/Nama Mapel
    hari: 'Senin',
    jam_mulai: '',
    jam_selesai: '',
    semester: 'Ganjil',
    tahun_ajaran: '2026/2027'
  });

  // =========================
  // FETCH DATA FROM API
  // =========================
  const fetchJadwalMaster = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5001/api/staff/jadwal', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setJadwalList(response.data.data || []);
    } catch (err) {
      console.error("Gagal memuat jadwal:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJadwalMaster();
  }, []);

  // =========================
  // HANDLER CRUD ACTIONS
  // =========================
  const handleOpenCreate = () => {
    setIsEditMode(false);
    setFormData({
      id_kelas: '', id_user: '', id_mapel: '',
      hari: 'Senin', jam_mulai: '', jam_selesai: '',
      semester: 'Ganjil', tahun_ajaran: '2026/2027'
    });
    setShowModal(true);
  };

  const handleOpenEdit = (item) => {
    setIsEditMode(true);
    setSelectedId(item.id_jadwal);
    setFormData({
      id_kelas: item.id_kelas,
      id_user: item.id_user,
      id_mapel: item.id_mapel,
      hari: item.hari,
      jam_mulai: item.jam_mulai || item.jam?.split(' - ')[0] || '',
      jam_selesai: item.jam_selesai || item.jam?.split(' - ')[1] || '',
      semester: item.semester || 'Ganjil',
      tahun_ajaran: item.tahun_ajaran || '2026/2027'
    });
    setShowModal(true);
  };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const payload = {
        ...formData,
        jam: `${formData.jam_mulai} - ${formData.jam_selesai}`
      };

      if (isEditMode) {
        await axios.put(`http://localhost:5001/api/staff/jadwal/${selectedId}`, payload, {
          headers: { Authorization: `Bearer ${token}` }
        });
        alert("Jadwal pelajaran berhasil diperbarui!");
      } else {
        await axios.post('http://localhost:5001/api/staff/jadwal', payload, {
          headers: { Authorization: `Bearer ${token}` }
        });
        alert("Jadwal pelajaran baru berhasil ditambahkan!");
      }
      setShowModal(false);
      fetchJadwalMaster();
    } catch (err) {
      alert("Gagal menyimpan data jadwal: " + (err.response?.data?.message || "Error database"));
    }
  };

  const handleDeleteSingle = async (idJadwal) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus jadwal ini? Tindakan ini akan menghapus sesi presensi kelas terkait.")) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`http://localhost:5001/api/staff/jadwal/${idJadwal}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        fetchJadwalMaster();
      } catch (err) {
        alert("Gagal menghapus jadwal.");
      }
    }
  };

  const handleResetSemester = async () => {
    if (window.confirm("⚠️ PERINGATAN KRITIS: Anda akan menghapus SELURUH jadwal pelajaran untuk persiapan ganti semester baru. Semua data jadwal saat ini akan dibersihkan. Lanjutkan?")) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete('http://localhost:5001/api/staff/jadwal/reset-massal', {
          headers: { Authorization: `Bearer ${token}` }
        });
        alert("Tabel jadwal berhasil dikosongkan. Silahkan input jadwal semester baru.");
        fetchJadwalMaster();
      } catch (err) {
        alert("Gagal melakukan reset semester.");
      }
    }
  };

  // Filter List Data berdasarkan Dropdown Kelas pilihan Staff
  const filteredJadwal = selectedKelasFilter === 'Semua' 
    ? jadwalList 
    : jadwalList.filter(item => item.nama_kelas === selectedKelasFilter || item.id_kelas === selectedKelasFilter);

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-800">
      
      {/* HEADER SECTION */}
      <div className="max-w-6xl mx-auto mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Panel Management Jadwal</h1>
          <p className="text-slate-500 text-xs mt-0.5">Otoritas Staff / Admin untuk menyusun, mengubah, dan mereset jadwal pelajaran sekolah.</p>
        </div>
        <div className="flex gap-2.5">
          <button 
            onClick={handleResetSemester}
            className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-4 py-2.5 rounded-xl text-xs font-bold transition-all"
          >
            <AlertTriangle size={14} />
            Reset Ganti Semester
          </button>
          <button 
            onClick={handleOpenCreate}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl text-xs font-black shadow-xs transition-all active:scale-95"
          >
            <Plus size={16} />
            Tambah Jadwal Baru
          </button>
        </div>
      </div>

      {/* FILTER PANEL */}
      <div className="max-w-6xl mx-auto bg-white p-4 rounded-xl border border-slate-100 shadow-2xs mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3 w-full max-w-xs">
          <Layers size={14} className="text-slate-400" />
          <label className="text-xs font-bold text-slate-500 uppercase whitespace-nowrap">Filter Kelas:</label>
          <select 
            value={selectedKelasFilter}
            onChange={(e) => setSelectedKelasFilter(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
          >
            <option value="Semua">Tampilkan Semua Kelas</option>
            {kelasOptions.map((k, i) => (
              <option key={i} value={k}>{k}</option>
            ))}
          </select>
        </div>
        <div className="text-[11px] font-bold text-slate-400">Total Terdata: {filteredJadwal.length} Jadwal</div>
      </div>

      {/* TABEL DATA UTAMA */}
      <div className="max-w-6xl mx-auto bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-400 font-bold border-b border-slate-100 uppercase tracking-wider">
                <th className="p-4">Hari / Waktu</th>
                <th className="p-4">Ruang Kelas</th>
                <th className="p-4">Mata Pelajaran</th>
                <th className="p-4">Guru Pengajar</th>
                <th className="p-4">Semester</th>
                <th className="p-4 text-center">Aksi Manajerial</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 font-medium text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-400 font-medium">
                    <RefreshCcw size={20} className="animate-spin mx-auto mb-2 text-indigo-500" /> Memuat data master jadwal pelajaran...
                  </td>
                </tr>
              ) : filteredJadwal.length > 0 ? (
                filteredJadwal.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-semibold">
                      <span className="block text-slate-900 font-bold">{item.hari}</span>
                      <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1 mt-0.5"><Clock size={11}/> {item.jam || `${item.jam_mulai} - ${item.jam_selesai}`}</span>
                    </td>
                    <td className="p-4 font-bold text-indigo-600">{item.nama_kelas || item.id_kelas}</td>
                    <td className="p-4 font-bold text-slate-900">{item.nama_mapel || `ID Mapel: ${item.id_mapel}`}</td>
                    <td className="p-4 text-slate-600">{item.nama_guru || `ID User: ${item.id_user}`}</td>
                    <td className="p-4"><span className="px-2 py-0.5 bg-slate-100 rounded text-slate-500 font-bold text-[10px] uppercase">{item.semester || 'Ganjil'}</span></td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors"
                          title="Edit Jadwal"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button 
                          onClick={() => handleDeleteSingle(item.id_jadwal)}
                          className="p-1.5 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors"
                          title="Hapus Jadwal"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="p-12 text-center text-slate-400">
                    <Calendar size={28} className="mx-auto mb-2 text-slate-300" />
                    Belum ada jadwal yang diinput untuk kelas ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* =========================
          MODAL FORM (MUTASI DATA)
      ========================= */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-[9999] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl w-full max-w-md overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-black text-slate-900 text-sm uppercase tracking-wide">
                {isEditMode ? 'Form Edit Jadwal Pelajaran' : 'Input Jadwal Pelajaran Baru'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={handleSubmitForm} className="p-5 space-y-4 text-xs">
              
              {/* INPUT KELAS */}
              <div>
                <label className="block font-bold text-slate-500 uppercase mb-1">Ruang Kelas Target</label>
                <select 
                  required
                  value={formData.id_kelas}
                  onChange={(e) => setFormData({...formData, id_kelas: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                >
                  <option value="">-- Pilih Kelas --</option>
                  {kelasOptions.map((k, idx) => <option key={idx} value={k}>{k}</option>)}
                </select>
              </div>

              {/* INPUT MATA PELAJARAN */}
              <div>
                <label className="block font-bold text-slate-500 uppercase mb-1">Mata Pelajaran</label>
                <input 
                  type="text" 
                  placeholder="Masukkan ID / Nama Mapel (Contoh: PW-01)"
                  required
                  value={formData.id_mapel}
                  onChange={(e) => setFormData({...formData, id_mapel: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* INPUT GURU */}
              <div>
                <label className="block font-bold text-slate-500 uppercase mb-1">Guru Pengajar</label>
                <input 
                  type="text" 
                  placeholder="Masukkan ID / Nama Lengkap Guru"
                  required
                  value={formData.id_user}
                  onChange={(e) => setFormData({...formData, id_user: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* HARI & JAM WAKTU */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-500 uppercase mb-1">Hari</label>
                  <select 
                    value={formData.hari}
                    onChange={(e) => setFormData({...formData, hari: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Senin">Senin</option><option value="Selasa">Selasa</option>
                    <option value="Rabu">Rabu</option><option value="Kamis">Kamis</option>
                    <option value="Jumat">Jumat</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase mb-1">Mulai</label>
                  <input 
                    type="text" placeholder="07:00" required
                    value={formData.jam_mulai}
                    onChange={(e) => setFormData({...formData, jam_mulai: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-center font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase mb-1">Selesai</label>
                  <input 
                    type="text" placeholder="08:30" required
                    value={formData.jam_selesai}
                    onChange={(e) => setFormData({...formData, jam_selesai: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-center font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* SEMESTER & TAHUN AJARAN */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-500 uppercase mb-1">Semester</label>
                  <select 
                    value={formData.semester}
                    onChange={(e) => setFormData({...formData, semester: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-500 uppercase mb-1">Tahun Ajaran</label>
                  <input 
                    type="text" required
                    value={formData.tahun_ajaran}
                    onChange={(e) => setFormData({...formData, tahun_ajaran: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setShowModal(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold px-4 py-2.5 rounded-lg"
                >
                  Batal
                </button>
                <button 
                  type="submit" 
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-black px-5 py-2.5 rounded-lg shadow-xs"
                >
                  {isEditMode ? 'Simpan Perubahan' : 'Simpan Jadwal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default JadwalPelajaran;