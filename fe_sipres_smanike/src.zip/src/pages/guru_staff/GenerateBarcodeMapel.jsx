import React, { useState } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { QrCode, Play, RefreshCw, BookOpen, Layers, Clock, AlertCircle } from 'lucide-react';

const GenerateQRMapel = () => {
  // ==========================================
  // SIMULASI MOCK DATA (Murni Frontend)
  // ==========================================
  const listMapel = [
    { id: 1, nama_mapel: 'Pemrograman Web Berbasis Komponen' },
    { id: 2, nama_mapel: 'Matematika Dasar' },
    { id: 3, nama_mapel: 'Basis Data Terdistribusi' },
    { id: 4, nama_mapel: 'Bahasa Indonesia' }
  ];

  const listKelas = [
    { id: 1, nama_kelas: 'X-RPL 1' },
    { id: 2, nama_kelas: 'XI-RPL 1' },
    { id: 3, nama_kelas: 'XII-RPL 1' },
    { id: 4, nama_kelas: 'XI-TKJ 2' }
  ];

  const listJam = [
    { id: 1, jam_mulai: '07:00', jam_selesai: '08:30' },
    { id: 2, jam_mulai: '08:30', jam_selesai: '10:00' },
    { id: 3, jam_mulai: '10:30', jam_selesai: '12:00' },
    { id: 4, jam_mulai: '13:00', jam_selesai: '14:30' }
  ];

  // =====================
  // STATE INPUT
  // =====================
  const [mapel, setMapel] = useState('');
  const [kelas, setKelas] = useState('');
  const [jam, setJam] = useState('');
  const [qrToken, setQrToken] = useState(null);

  // =====================
  // SIMULASI GENERATE QR
  // =====================
  const handleGenerate = (e) => {
    e.preventDefault();
    if (!mapel || !kelas || !jam) {
      alert('Semua field harus diisi!');
      return;
    }

    // Membuat Token Simulasi Unik berbasis teks gabungan + timestamp waktu
    const mockSecureToken = `SMANIKE-${kelas.replace(/\s+/g, '')}-${Date.now()}`;
    setQrToken(mockSecureToken);
  };

  // =====================
  // SIMULASI RESET KELAS
  // =====================
  const handleReset = () => {
    setQrToken(null);
    setMapel('');
    setKelas('');
    setJam('');
  };

  return (
    <div className="max-w-4xl mx-auto font-sans pb-12">
      {/* HEADER UTAMA */}
      <div className="mb-6">
        <h1 className="text-2xl font-black text-[#3e2723] uppercase">Mulai Sesi Mengajar & QR Presensi</h1>
        <p className="text-gray-500 text-sm">Buka jam pelajaran hari ini untuk mengaktifkan QR Code kehadiran bagi siswa.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* PANEL KIRI: FORM SELEKSI GURU */}
        <div className="md:col-span-2 space-y-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <h2 className="text-xs font-black text-[#3e2723] uppercase mb-4 tracking-wider">Konfigurasi Kelas</h2>
            
            <form onSubmit={handleGenerate} className="space-y-4">
              {/* SELECT MAPEL */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Mata Pelajaran</label>
                <div className="relative">
                  <select
                    value={mapel}
                    onChange={(e) => setMapel(e.target.value)}
                    disabled={!!qrToken}
                    className="w-full px-3 py-2.5 pl-9 border border-gray-200 rounded-xl text-xs font-bold bg-white focus:outline-none focus:border-[#E67E22] disabled:bg-gray-50 disabled:text-gray-400 appearance-none"
                  >
                    <option value="">-- Pilih Mapel --</option>
                    {listMapel.map((item) => (
                      <option key={item.id} value={item.nama_mapel}>
                        {item.nama_mapel}
                      </option>
                    ))}
                  </select>
                  <BookOpen size={14} className="absolute left-3 top-3.5 text-gray-400" />
                </div>
              </div>

              {/* SELECT KELAS */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Target Kelas</label>
                <div className="relative">
                  <select
                    value={kelas}
                    onChange={(e) => setKelas(e.target.value)}
                    disabled={!!qrToken}
                    className="w-full px-3 py-2.5 pl-9 border border-gray-200 rounded-xl text-xs font-bold bg-white focus:outline-none focus:border-[#E67E22] disabled:bg-gray-50 disabled:text-gray-400 appearance-none"
                  >
                    <option value="">-- Pilih Kelas --</option>
                    {listKelas.map((item) => (
                      <option key={item.id} value={item.nama_kelas}>
                        {item.nama_kelas}
                      </option>
                    ))}
                  </select>
                  <Layers size={14} className="absolute left-3 top-3.5 text-gray-400" />
                </div>
              </div>

              {/* SELECT ALOKASI JAM */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Alokasi Waktu Jam</label>
                <div className="relative">
                  <select
                    value={jam}
                    onChange={(e) => setJam(e.target.value)}
                    disabled={!!qrToken}
                    className="w-full px-3 py-2.5 pl-9 border border-gray-200 rounded-xl text-xs font-bold bg-white focus:outline-none focus:border-[#E67E22] disabled:bg-gray-50 disabled:text-gray-400 appearance-none"
                  >
                    <option value="">-- Pilih Jam --</option>
                    {listJam.map((item) => {
                      const displayJam = `${item.jam_mulai} - ${item.jam_selesai}`;
                      return (
                        <option key={item.id} value={displayJam}>
                          {displayJam}
                        </option>
                      );
                    })}
                  </select>
                  <Clock size={14} className="absolute left-3 top-3.5 text-gray-400" />
                </div>
              </div>

              {/* ACTION BUTTON */}
              {!qrToken ? (
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-[#E67E22] hover:bg-[#d35400] text-white text-xs font-bold rounded-xl shadow-md transition"
                >
                  <Play size={14} /> Buka Kelas & Generate QR
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleReset}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-md transition"
                >
                  Tutup Sesi Mengajar
                </button>
              )}
            </form>
          </div>

          {/* BOX STATUS CONTEXT */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-start gap-3">
            <AlertCircle className={`shrink-0 mt-0.5 ${qrToken ? 'text-emerald-500' : 'text-amber-500'}`} size={18} />
            <div>
              <h4 className={`text-xs font-bold uppercase ${qrToken ? 'text-emerald-700' : 'text-amber-700'}`}>
                {qrToken ? 'Sesi Presensi Aktif' : 'Menunggu Aktivasi'}
              </h4>
              <p className="text-[11px] text-gray-500 mt-0.5">
                {qrToken 
                  ? `Siswa kelas ${kelas} sekarang bisa memindai QR Code ini untuk mencatat kehadiran.`
                  : 'Silakan pilih kombinasi mengajar lalu aktifkan QR Code untuk dipajang di proyektor kelas.'
                }
              </p>
            </div>
          </div>
        </div>

        {/* PANEL KANAN: DISPLAY QR CODE CANVAS */}
        <div className="md:col-span-3">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col items-center justify-center min-h-[380px] relative text-center">
            {qrToken ? (
              <div className="space-y-5 w-full flex flex-col items-center">
                <div className="space-y-1">
                  <span className="bg-[#f5e6d3] text-[#3e2723] text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider">{kelas}</span>
                  <h3 className="text-lg font-black text-[#3e2723] mt-1">{mapel}</h3>
                  <p className="text-xs text-gray-400 font-medium">Jam Pelajaran: {jam}</p>
                </div>

                {/* CONTAINER REAL QR CANVAS */}
                <div className="p-5 bg-white rounded-2xl border border-gray-100 shadow-md relative group my-1">
                  <QRCodeCanvas 
                    value={qrToken} 
                    size={190}
                    bgColor={"#ffffff"}
                    fgColor={"#3e2723"} 
                    level={"H"}
                    includeMargin={true}
                  />
                </div>

                <div className="flex items-center gap-2 text-[11px] text-gray-400 font-medium bg-gray-50 px-3 py-1.5 rounded-lg">
                  <RefreshCw size={12} className="animate-spin text-[#E67E22]" />
                  <span>Sistem Enkripsi Token Aktif (Simulasi)</span>
                </div>

                <div className="text-[9px] bg-gray-50 font-mono px-3 py-2 rounded-lg text-gray-400 max-w-xs truncate border border-gray-100">
                  Secure Token: {qrToken}
                </div>
              </div>
            ) : (
              <div className="text-gray-300 flex flex-col items-center py-12">
                <QrCode size={80} className="stroke-1 mb-3 text-gray-200 animate-pulse" />
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Layar QR Presensi</h3>
                <p className="text-xs text-gray-400 max-w-xs mt-1">
                  QR Code dinamis akan dirender di area ini setelah tombol aktivasi ditekan.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GenerateQRMapel;