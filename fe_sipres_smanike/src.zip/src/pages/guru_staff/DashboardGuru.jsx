import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Users, ShieldAlert, Clock, ArrowRight, BookOpen, Search, CalendarCheck } from 'lucide-react';

const DashboardGuru = ({ userRole = 'guru', isPiket = true }) => {
  // Akun guru yang diasumsikan sedang login di sistem
  const guruLogin = "Rian Hidayat, A.Md.Kom.";
  
  // Mendapatkan teks tanggal hari ini
  const opsiTanggal = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const tanggalHariIni = new Date().toLocaleDateString('id-ID', { ...opsiTanggal });

  // ========================================================
  // MASTER DATA INPUTAN JADWAL 1 SEMESTER (KOLEKTIF GURU)
  // ========================================================
  const [masterJadwal] = useState([
    { id: 1, namaGuru: "Rian Hidayat, A.Md.Kom.", hari: "Senin", jam: "07:00 - 08:30", kelas: "XI-RPL 1", mapel: "Pemrograman Web Berbasis Komponen" },
    { id: 2, namaGuru: "Rian Hidayat, A.Md.Kom.", hari: "Senin", jam: "08:30 - 10:00", kelas: "XII-RPL 1", mapel: "Basis Data Terdistribusi" },
    { id: 3, namaGuru: "Siti Aminah, S.Pd.", hari: "Senin", jam: "07:00 - 08:30", kelas: "X-RPL 1", mapel: "Matematika Dasar" },
    { id: 4, namaGuru: "Budi Santoso, M.T.", hari: "Selasa", jam: "07:00 - 08:30", kelas: "XI-TKJ 2", mapel: "Dasar Jaringan Komputer" },
    { id: 5, namaGuru: "Rian Hidayat, A.Md.Kom.", hari: "Selasa", jam: "10:30 - 12:00", kelas: "X-RPL 1", mapel: "Matematika Dasar" },
    { id: 6, namaGuru: "Siti Aminah, S.Pd.", hari: "Rabu", jam: "08:30 - 10:00", kelas: "XII-RPL 1", mapel: "Matematika Dasar" },
    { id: 7, namaGuru: "Rian Hidayat, A.Md.Kom.", hari: "Rabu", jam: "13:00 - 14:30", kelas: "X-RPL 1", mapel: "Matematika Dasar" },
    { id: 8, namaGuru: "Budi Santoso, M.T.", hari: "Kamis", jam: "08:30 - 10:00", kelas: "XII-RPL 1", mapel: "Dasar Jaringan Komputer" },
    { id: 9, namaGuru: "Rian Hidayat, A.Md.Kom.", hari: "Kamis", jam: "07:00 - 08:30", kelas: "XI-TKJ 2", mapel: "Dasar Jaringan Komputer" },
  ]);

  // List Data Dropdown Pilihan Filter
  const daftarGuru = ["Semua Guru", "Rian Hidayat, A.Md.Kom.", "Siti Aminah, S.Pd.", "Budi Santoso, M.T."];
  const daftarHari = ["Semua Hari", "Senin", "Selasa", "Rabu", "Kamis"];

  // ========================================================
  // STATE MANAGEMENT FILTER
  // ========================================================
  const [filterGuru, setFilterGuru] = useState("Semua Guru");
  const [filterHari, setFilterHari] = useState("Semua Hari");

  // Logika Penyaringan Data Berdasarkan Pilihan Dropdown
  const jadwalTersaring = masterJadwal.filter(item => {
    const cocokGuru = filterGuru === "Semua Guru" || item.namaGuru === filterGuru;
    const cocokHari = filterHari === "Semua Hari" || item.hari === filterHari;
    return cocokGuru && cocokHari;
  });

  return (
    <div className="max-w-5xl mx-auto font-sans pb-12">
      
      {/* WELCOME & CONTEXT BANNER */}
      <div className="bg-[#3e2723] text-white p-6 rounded-2xl shadow-sm mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-[10px] font-black uppercase tracking-widest text-[#E67E22] bg-[#E67E22]/10 px-2.5 py-1 rounded-md">
            {userRole === 'superadmin' ? 'Super Admin Portal' : 'Portal Resmi Guru'}
          </span>
          <h1 className="text-xl font-black mt-2 text-white">Master Jadwal Pelajaran Semester</h1>
          <p className="text-gray-300 text-xs mt-0.5">Akun Aktif Anda: <span className="text-[#E67E22] font-bold">{guruLogin}</span></p>
        </div>
        <div className="bg-white/10 px-4 py-2.5 rounded-xl border border-white/5 backdrop-blur-xs shrink-0 text-right">
          <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Hari & Tanggal</p>
          <p className="text-xs font-black text-[#E67E22] mt-0.5">{tanggalHariIni}</p>
        </div>
      </div>

      {/* STATS ROW (RINGKASAN ANGKA) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-amber-50 text-[#E67E22] rounded-xl">
            <BookOpen size={20} />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total Plotting Sesi</p>
            <p className="text-base font-black text-[#3e2723]">{masterJadwal.length} Jadwal Inputan</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3.5">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Users size={20} />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total Siswa Terdata</p>
            <p className="text-base font-black text-[#3e2723]">105 Siswa</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs flex items-center gap-3.5">
          <div className={`p-3 rounded-xl ${isPiket ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-50 text-gray-400'}`}>
            <ShieldAlert size={20} />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Tugas Piket Harian</p>
            <p className={`text-base font-black ${isPiket ? 'text-emerald-600' : 'text-[#3e2723]'}`}>
              {isPiket ? 'Aktif Hari Ini' : 'Tidak Bertugas'}
            </p>
          </div>
        </div>
      </div>

      {/* FILTER PANEL INPUTAN DROPDOWN */}
      <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm mb-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Filter Nama Pendidik / Guru</label>
          <div className="relative">
            <select
              value={filterGuru}
              onChange={(e) => setFilterGuru(e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-xs font-bold bg-white text-gray-700 focus:outline-none focus:border-[#E67E22] appearance-none"
            >
              {daftarGuru.map((g, i) => <option key={i} value={g}>{g}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Filter Hari Kerja (Senin - Kamis)</label>
          <div className="relative">
            <select
              value={filterHari}
              onChange={(e) => setFilterHari(e.target.value)}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-xs font-bold bg-white text-gray-700 focus:outline-none focus:border-[#E67E22] appearance-none"
            >
              {daftarHari.map((h, i) => <option key={i} value={h}>{h}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* JADWAL MENGANJAR CONTAINER (TABEL KOLEKTIF SEMESTER) */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="mb-5 flex justify-between items-center">
          <div>
            <h2 className="text-sm font-black text-[#3e2723] uppercase tracking-wider flex items-center gap-2">
              <Calendar size={16} className="text-[#E67E22]" /> Lembar Plotting Jadwal Kolektif
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">Menampilkan rekap data jadwal mengajar berdasarkan filter yang dipilih.</p>
          </div>
          <span className="text-[10px] text-gray-400 font-bold bg-gray-50 px-2.5 py-1 rounded-md uppercase">
            Total Sesi: {jadwalTersaring.length}
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-gray-100">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-500 font-bold text-xs uppercase tracking-wider border-b border-gray-100">
                <th className="p-4 w-24">Hari</th>
                <th className="p-4 w-32">Jam Ke-</th>
                <th className="p-4">Nama Lengkap Guru</th>
                <th className="p-4">Mata Pelajaran</th>
                <th className="p-4 text-center w-20">Kelas</th>
                <th className="p-4 text-center w-32">Aksi Presensi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm text-gray-700">
              {jadwalTersaring.length > 0 ? (
                jadwalTersaring.map((item) => {
                  const isMyJadwal = item.namaGuru === guruLogin;

                  return (
                    <tr key={item.id} className={`transition-all ${isMyJadwal ? 'bg-amber-50/40 hover:bg-amber-50/70' : 'hover:bg-gray-50/50'}`}>
                      
                      {/* HARI */}
                      <td className="p-4 font-black text-xs uppercase tracking-wide text-gray-500">{item.hari}</td>
                      
                      {/* JAM PELAJARAN */}
                      <td className="p-4 font-mono text-xs text-gray-600 font-semibold flex items-center gap-1.5">
                        <Clock size={12} className="text-[#E67E22]" /> {item.jam}
                      </td>
                      
                      {/* NAMA GURU */}
                      <td className="p-4 font-bold text-[#3e2723]">
                        <div className="flex items-center gap-1.5">
                          <span>{item.namaGuru}</span>
                          {isMyJadwal && (
                            <span className="text-[8px] bg-[#E67E22] text-white font-extrabold px-1.5 py-0.5 rounded-sm uppercase tracking-tighter">Anda</span>
                          )}
                        </div>
                      </td>
                      
                      {/* MATA PELAJARAN */}
                      <td className="p-4 font-medium text-gray-600 text-xs">{item.mapel}</td>
                      
                      {/* KELAS */}
                      <td className="p-4 text-center font-black text-xs text-gray-700">
                        <span className="bg-gray-100 px-2 py-0.5 rounded-md">{item.kelas}</span>
                      </td>
                      
                      {/* AKSI KONDISIONAL BERDASARKAN GURU YANG LOGIN */}
                      <td className="p-4 text-center">
                        {isMyJadwal ? (
                          <Link 
                            to="/guru_staff/GenerateBarcodeMapel"
                            className="inline-flex items-center gap-1 text-[11px] font-black bg-[#E67E22] hover:bg-[#d35400] text-white px-2.5 py-1.5 rounded-lg transition-all shadow-xs"
                          >
                            Buka Absen <ArrowRight size={10} />
                          </Link>
                        ) : (
                          <span className="text-[10px] font-bold text-gray-300 italic">Bukan Kelas Anda</span>
                        )}
                      </td>

                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="6" className="text-center py-12 text-xs font-bold text-gray-400 uppercase tracking-wider bg-gray-50/50">
                    Tidak ditemukan kecocokan data jadwal pelajaran
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* QUICK ACCESS LINK KHUSUS GURU PIKET */}
      {isPiket && (
        <div className="mt-6 bg-emerald-50/50 rounded-2xl border border-emerald-100/50 p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-start gap-3">
            <CalendarCheck className="text-emerald-600 shrink-0 mt-0.5" size={20} />
            <div>
              <h4 className="text-xs font-black text-emerald-800 uppercase tracking-wide">Akses Cepat Guru Piket</h4>
              <p className="text-[11px] text-emerald-600 mt-0.5">Hari ini Anda ditugaskan piket. Anda diizinkan untuk mengontrol dan merekap presensi harian seluruh siswa.</p>
            </div>
          </div>
          <Link 
            to="/guru_staff/RekapHarian"
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs transition-all shrink-0"
          >
            Lihat Rekap Harian
          </Link>
        </div>
      )}

    </div>
  );
};

export default DashboardGuru;