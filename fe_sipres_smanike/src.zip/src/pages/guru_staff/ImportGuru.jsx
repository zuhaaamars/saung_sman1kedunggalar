import React, { useState } from 'react';
import axios from 'axios';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  Download, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  Edit3, 
  Trash2, 
  X, 
  Check 
} from 'lucide-react';

const ImportGuru = () => {
  // --- STATE UNTUK FILE UPLOAD ---
  const [file, setFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState({ type: '', message: '' });

  // --- STATE UNTUK CRUD DATA GURU (Mock Data Frontend) ---
  const [dataGuru, setDataGuru] = useState([
    { id: 1, nip_nuptk: '198203112009021003', nama_guru: 'Drs. H. Ahmad Subarjo, M.Pd.', no_hp_pribadi: '081234567890', role_akses: 'guru' },
    { id: 2, nip_nuptk: '199508222021032001', nama_guru: 'Siti Aminah, S.Pd.', no_hp_pribadi: '085712345678', role_akses: 'guru' },
    { id: 3, nip_nuptk: '200110052024011002', nama_guru: 'Rian Hidayat, A.Md.Kom.', no_hp_pribadi: '089598765432', role_akses: 'staf' },
  ]);

  // State Form Modal (Tambah / Edit)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [formInput, setFormInput] = useState({
    nip_nuptk: '',
    nama_guru: '',
    no_hp_pribadi: '',
    role_akses: 'guru'
  });

  // --- LOGIK HANDLING DRAG & DROP EXCEL ---
  const handleDragOver = (e) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = () => { setIsDragging(false); };
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    validateAndSetFile(e.dataTransfer.files[0]);
  };
  const handleFileChange = (e) => { validateAndSetFile(e.target.files[0]); };

  const validateAndSetFile = (selectedFile) => {
    if (!selectedFile) return;
    const fileExtension = selectedFile.name.split('.').pop().toLowerCase();
    if (fileExtension !== 'xlsx' && fileExtension !== 'xls') {
      setStatus({ type: 'error', message: 'Format file salah! Sistem hanya menerima ekstensi Excel (.xlsx atau .xls)' });
      setFile(null);
      return;
    }
    setFile(selectedFile);
    setStatus({ type: '', message: '' });
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setStatus({ type: 'error', message: 'Pilih dokumen Excel pendidik terlebih dahulu!' });
      return;
    }
    setIsLoading(true);
    setStatus({ type: '', message: '' });

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://localhost:5001/api/staff/import-guru', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.data.status === 'success') {
        setStatus({ type: 'success', message: response.data.message || 'Seluruh data Guru & Staf berhasil disimpan!' });
        setFile(null);
      }
    } catch (err) {
      setStatus({ 
        type: 'error', 
        message: err.response?.data?.message || 'Proses sinkronisasi gagal. Periksa integritas format kolom data Anda.' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  // --- LOGIK HANDLING CRUD (FRONTEND ONLY) ---
  const openAddModal = () => {
    setIsEditing(false);
    setFormInput({ nip_nuptk: '', nama_guru: '', no_hp_pribadi: '', role_akses: 'guru' });
    setIsModalOpen(true);
  };

  const openEditModal = (guru) => {
    setIsEditing(true);
    setCurrentId(guru.id);
    setFormInput({
      nip_nuptk: guru.nip_nuptk,
      nama_guru: guru.nama_guru,
      no_hp_pribadi: guru.no_hp_pribadi,
      role_akses: guru.role_akses
    });
    setIsModalOpen(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormInput(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveData = (e) => {
    e.preventDefault();
    if (!formInput.nip_nuptk || !formInput.nama_guru || !formInput.no_hp_pribadi) {
      alert("Semua kolom data wajib diisi!");
      return;
    }

    if (isEditing) {
      // Perbarui Data (Update)
      setDataGuru(prev => prev.map(item => item.id === currentId ? { ...item, ...formInput } : item));
    } else {
      // Tambah Data Baru (Create)
      const newData = {
        id: Date.now(),
        ...formInput
      };
      setDataGuru(prev => [...prev, newData]);
    }
    setIsModalOpen(false);
  };

  const handleDeleteGuru = (id) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus data pendidik ini?")) {
      setDataGuru(prev => prev.filter(item => item.id !== id));
    }
  };

  return (
    <div className="max-w-5xl mx-auto font-sans pb-12">
      {/* HEADER JUDUL */}
      <div className="mb-6">
        <h1 className="text-2xl font-black text-[#3e2723] uppercase">Manajemen & Import Data Pendidik</h1>
        <p className="text-gray-500 text-sm">Integrasikan file Excel atau kelola data kepegawaian guru mapel/wali kelas secara langsung.</p>
      </div>

      {/* SECTION ATAS: IMPORT UTILITY */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* PANEL KIRI: UPLOAD BOX */}
        <div className="md:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-[#e8d2b8]/50 flex flex-col justify-between">
          <form onSubmit={handleUpload} className="space-y-5">
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-6 text-center flex flex-col items-center justify-center cursor-pointer transition-all duration-200 min-h-[180px] ${
                isDragging ? 'border-[#E67E22] bg-[#f5e6d3]/30' : file ? 'border-[#3e2723] bg-gray-50' : 'border-gray-300 hover:border-[#E67E22] bg-gray-50/50'
              }`}
              onClick={() => document.getElementById('excel-file-guru').click()}
            >
              <input id="excel-file-guru" type="file" accept=".xlsx, .xls" className="hidden" onChange={handleFileChange} />
              {file ? (
                <>
                  <FileSpreadsheet size={40} className="text-[#3e2723] mb-2 animate-bounce" />
                  <p className="text-sm font-bold text-[#3e2723] break-all px-4">{file.name}</p>
                  <p className="text-xs text-gray-400 mt-1">({(file.size / 1024).toFixed(1)} KB)</p>
                  <button type="button" onClick={(e) => { e.stopPropagation(); setFile(null); }} className="mt-2 text-xs font-bold text-red-500 hover:underline">Ganti file</button>
                </>
              ) : (
                <>
                  <UploadCloud size={40} className="text-gray-400 mb-2" />
                  <p className="text-sm font-bold text-gray-700">Tarik & Jatuhkan file Excel Guru di sini</p>
                  <p className="text-xs text-gray-400 mt-1">atau klik untuk menelusuri dokumen komputer</p>
                </>
              )}
            </div>

            {status.message && (
              <div className={`p-4 rounded-xl flex items-start gap-3 border ${status.type === 'error' ? 'bg-red-50 border-red-200 text-red-700' : 'bg-green-50 border-green-200 text-green-700'}`}>
                {status.type === 'error' ? <AlertTriangle size={20} className="shrink-0 mt-0.5" /> : <CheckCircle2 size={20} className="shrink-0 mt-0.5" />}
                <p className="text-sm font-medium leading-relaxed">{status.message}</p>
              </div>
            )}

            <button type="submit" disabled={isLoading || !file} className="w-full h-12 bg-[#3e2723] hover:bg-[#52332e] text-white rounded-xl font-bold text-sm tracking-wide transition-all disabled:opacity-40 flex items-center justify-center gap-2 shadow-md">
              {isLoading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : "Proses & Simpan Data Guru via Excel"}
            </button>
          </form>
        </div>

        {/* PANEL KANAN: INSTRUKSI */}
        <div className="space-y-4">
          <div className="bg-[#f5e6d3]/40 p-5 rounded-2xl border border-[#e8d2b8]/60 text-center">
            <h3 className="font-bold text-sm text-[#3e2723] mb-1">Butuh Template Excel?</h3>
            <p className="text-xs text-gray-500 mb-3">Gunakan format kolom kepegawaian resmi.</p>
            <a href="/templates/template_import_guru.xlsx" download className="inline-flex items-center justify-center gap-2 w-full py-2.5 bg-[#E67E22] hover:bg-[#d35400] text-white font-bold text-xs rounded-xl shadow-sm transition">
              <Download size={14} /> Unduh Template Excel
            </a>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm text-xs text-gray-600">
            <h4 className="font-bold text-[#3e2723] uppercase mb-2">Ketentuan Sistem:</h4>
            <ul className="space-y-1 list-disc list-inside">
              <li><span className="font-bold">nip_nuptk</span> wajib unik (Username).</li>
              <li><span className="font-bold">role_akses</span>: <code className="bg-gray-100 px-1 rounded">guru</code> atau <code className="bg-gray-100 px-1 rounded">staf</code>.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* SECTION BAWAH: DATA TABLE CRUD DISPLAY                 */}
      {/* ======================================================== */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-black text-[#3e2723]">Daftar Pendidik Terdaftar</h2>
            <p className="text-xs text-gray-400">Total terdata di frontend: {dataGuru.length} personil</p>
          </div>
          <button 
            onClick={openAddModal}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#E67E22] hover:bg-[#d35400] text-white text-xs font-bold rounded-xl shadow-sm transition"
          >
            <Plus size={16} /> Tambah Guru Manual
          </button>
        </div>

        {/* TABEL DATA DISPLAY (READ) */}
        <div className="overflow-x-auto rounded-xl border border-gray-100">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-500 font-bold text-xs uppercase tracking-wider border-b border-gray-100">
                <th className="p-4 w-12 text-center">No</th>
                <th className="p-4">NIP / NUPTK</th>
                <th className="p-4">Nama Lengkap</th>
                <th className="p-4">No. WhatsApp</th>
                <th className="p-4 text-center">Role</th>
                <th className="p-4 text-center w-28">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm text-gray-700">
              {dataGuru.length === 0 ? (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-gray-400 text-xs font-medium">Belum ada data guru. Silakan import excel atau tambah manual.</td>
                </tr>
              ) : (
                dataGuru.map((guru, index) => (
                  <tr key={guru.id} className="hover:bg-gray-50/70 transition">
                    <td className="p-4 text-center text-xs font-bold text-gray-400">{index + 1}</td>
                    <td className="p-4 font-mono text-xs font-semibold text-gray-600">{guru.nip_nuptk}</td>
                    <td className="p-4 font-bold text-[#3e2723]">{guru.nama_guru}</td>
                    <td className="p-4 text-xs">{guru.no_hp_pribadi}</td>
                    <td className="p-4 text-center">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase ${
                        guru.role_akses === 'staf' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {guru.role_akses === 'staf' ? 'Staff TU' : 'Guru'}
                      </span>
                    </td>
                    <td className="p-4 text-center flex items-center justify-center gap-2">
                      <button 
                        onClick={() => openEditModal(guru)}
                        className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg transition" 
                        title="Edit Data"
                      >
                        <Edit3 size={14} />
                      </button>
                      <button 
                        onClick={() => handleDeleteGuru(guru.id)}
                        className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition" 
                        title="Hapus Data"
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ======================================================== */}
      {/* MODAL POPUP FORM (CREATE / UPDATE)                       */}
      {/* ======================================================== */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-xl border border-gray-100 overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gray-50">
              <h3 className="font-bold text-[#3e2723] text-sm uppercase">
                {isEditing ? "📝 Edit Data Pendidik" : "✨ Tambah Pendidik Baru"}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={18} />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSaveData} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">NIP / NUPTK (Username)</label>
                <input 
                  type="text" name="nip_nuptk" value={formInput.nip_nuptk} onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#E67E22]" placeholder="Contoh: 19820311..."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Nama Lengkap beserta Gelar</label>
                <input 
                  type="text" name="nama_guru" value={formInput.nama_guru} onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#E67E22]" placeholder="Contoh: Ahmad, S.Pd."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">No. WhatsApp Aktif</label>
                <input 
                  type="text" name="no_hp_pribadi" value={formInput.no_hp_pribadi} onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#E67E22]" placeholder="Contoh: 0812345..."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Hak Akses Sistem (Role)</label>
                <select 
                  name="role_akses" value={formInput.role_akses} onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:border-[#E67E22]"
                >
                  <option value="guru">Guru (Tenaga Pendidik)</option>
                  <option value="staf">Staf (Tata Usaha / Kependidikan)</option>
                </select>
              </div>

              {/* Modal Footer */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-gray-100 mt-6">
                <button 
                  type="button" onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-200 text-gray-500 text-xs font-bold rounded-xl hover:bg-gray-50 transition"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#3e2723] hover:bg-[#52332e] text-white text-xs font-bold rounded-xl shadow-sm transition"
                >
                  <Check size={14} /> Simpan Data
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImportGuru;