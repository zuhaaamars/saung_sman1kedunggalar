import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { 
  Camera, MapPin, Navigation, History, 
  CheckCircle2, Clock, RefreshCw, Map as MapIcon,
  ChevronRight, AlertCircle, Info, FileText
} from 'lucide-react';

const TARGET_COORDS = { lat: -7.507569, lng: 111.182868 }; // Koordinat Sekolah SMAN 1 Kedunggalar
const MAX_RADIUS = 100; // Radius Batas 100 Meter

const ScanPresensiHarian = () => {
  const [isWithinRadius, setIsWithinRadius] = useState(false);
  const [presensiStatus, setPresensiStatus] = useState('idle');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [capturedImage, setCapturedImage] = useState(null);
  const [location, setLocation] = useState({ lat: null, lng: null });
  const [distance, setDistance] = useState(0);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  
  // State Baru: Untuk memantau status hari ini yang diberikan oleh Staff Admin
  const [statusHariIni, setStatusHariIni] = useState('Belum Absen'); // 'Hadir', 'Sakit', 'Izin', 'Alfa', 'Belum Absen'
  const [keteranganAdmin, setKeteranganAdmin] = useState('');
  
  const videoRef = useRef(null);

  // Fungsi Rumus Haversine untuk Hitung Jarak Geofence
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    if (!lat1 || !lon1) return 0;
    const R = 6371000; // Radius bumi dalam meter
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Efek Jam Digital Real-time
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Efek Deteksi GPS Lokasi Live Siswa & Cek Status
  useEffect(() => {
    fetchHistoryAndStatus(); 

    if ("geolocation" in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const uLat = position.coords.latitude;
          const uLng = position.coords.longitude;
          setLocation({ lat: uLat, lng: uLng });
          
          const d = calculateDistance(uLat, uLng, TARGET_COORDS.lat, TARGET_COORDS.lng);
          setDistance(d);
          setIsWithinRadius(d <= MAX_RADIUS);
        },
        (err) => console.error("GPS Terkendala:", err),
        { enableHighAccuracy: true, maximumAge: 5000 }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    } else {
      alert("Perangkat Anda tidak mendukung fitur GPS Geolocation.");
    }
  }, []);

  // Ambil Data Riwayat & Status Absen Hari Ini dari Backend
  const fetchHistoryAndStatus = async () => {
    try {
      const userRaw = localStorage.getItem('user');
      if (!userRaw) return;

      const userData = JSON.parse(userRaw);
      const siswaId = userData.siswa_id || userData.id;

      if (!siswaId) return;

      const token = localStorage.getItem("token");

      // 1. Ambil Riwayat
      const resHistory = await axios.get(`http://localhost:5001/api/presensi/riwayat/${siswaId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (resHistory.data.status === "success") {
        setHistory(resHistory.data.data);
      }

      // 2. Ambil Status Hari Ini (Untuk mendeteksi apakah Admin sudah menginputkan Sakit/Izin/Alfa)
      const resStatus = await axios.get(`http://localhost:5001/api/presensi/status-hari-ini/${siswaId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (resStatus.data.status === "success" && resStatus.data.data) {
        setStatusHariIni(resStatus.data.data.status_kehadiran);
        setKeteranganAdmin(resStatus.data.data.keterangan || '');
        if (resStatus.data.data.status_kehadiran === 'Hadir') {
          setPresensiStatus('success');
        }
      }
    } catch (err) {
      console.error("Gagal mengambil data status/riwayat:", err);
    }
  };

  // Kontrol Pembukaan Akses Kamera
  const handlePresensiAction = async () => {
    // Kunci tombol jika Admin sudah menandai siswa sebagai Sakit atau Izin
    if (statusHariIni === 'Sakit' || statusHariIni === 'Izin') {
      return;
    }

    if (!isWithinRadius) {
      alert(`Akses Ditolak! Anda berada di luar area sekolah (Jarak: ${distance.toFixed(1)}m).`);
      return;
    }

    if (presensiStatus === 'idle') {
      setPresensiStatus('taking_photo');
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {
        alert("Gagal membuka kamera perangkat: " + err);
        setPresensiStatus('idle');
      }
    } else if (presensiStatus === 'taking_photo' && !capturedImage) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      canvas.getContext('2d').drawImage(videoRef.current, 0, 0);
      setCapturedImage(canvas.toDataURL('image/png'));
      
      if (videoRef.current.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    }
  };

  // Kirim Payload Absen ke Server Backend
  const submitPresensi = async () => {
    setLoading(true);
    const userRaw = localStorage.getItem('user'); 
    if (!userRaw) {
      alert("Sesi masuk habis, silahkan login kembali.");
      setLoading(false);
      return;
    }

    try {
      const userData = JSON.parse(userRaw);
      const siswaId = userData.siswa_id || userData.id;

      const payload = {
        id_siswa: siswaId,
        foto_bukti: capturedImage,
        latitude: location.lat,
        longitude: location.lng,
        status_kehadiran: 'Hadir',
        metode_presensi: 'Geofencing'
      };

      const response = await axios.post('http://localhost:5001/api/presensi/harian', payload, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
      });

      if (response.data.status === 'success') {
        setPresensiStatus('success');
        setStatusHariIni('Hadir');
        fetchHistoryAndStatus();
      }
    } catch (error) {
      console.error("Database Error:", error.response?.data);
      alert("Gagal mengirim absensi: " + (error.response?.data?.message || "Internal Database Error"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-800">
      
      {/* HEADER SECTION */}
      <header className="max-w-5xl mx-auto mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Presensi Geofencing Mandiri</h1>
          <p className="text-slate-500 text-xs flex items-center gap-1.5 mt-0.5">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            Lokasi Validasi: <span className="font-bold text-slate-700">SMAN 1 Kedunggalar</span>
          </p>
        </div>
        
        {/* Indikator Status Geofence Aktif */}
        <div className={`px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-black shadow-xs tracking-wide uppercase transition-all ${
          statusHariIni === 'Sakit' || statusHariIni === 'Izin' 
            ? 'bg-amber-100 text-amber-700 border border-amber-200'
            : isWithinRadius 
              ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' 
              : 'bg-rose-100 text-rose-700 border border-rose-200'
        }`}>
          {statusHariIni === 'Sakit' || statusHariIni === 'Izin' ? <FileText size={14} /> : isWithinRadius ? <CheckCircle2 size={14} /> : <AlertCircle size={14} />}
          {statusHariIni === 'Sakit' || statusHariIni === 'Izin' ? 'Izin Terverifikasi' : isWithinRadius ? 'Akses Terbuka (Dalam Area)' : 'Akses Terkunci (Luar Area)'}
        </div>
      </header>

      <main className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* KANVAS KAMERA & JAM UTAMA (KIRI) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-slate-100">
            
            <div className="p-5 text-center border-b border-slate-100 bg-slate-50/50">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                {currentTime.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
              <h2 className="text-4xl font-black text-slate-900 tabular-nums tracking-tight">
                {currentTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).replace(/\./g, ':')}
              </h2>
            </div>

            {/* AREA RENDER STREAM KAMERA / INFORMASI DINAMIS */}
            <div className="relative aspect-video bg-slate-900 flex items-center justify-center overflow-hidden">
              
              {/* KONDISI 1: JIKA SISWA TERDATA SAKIT ATAU IZIN OLEH ADMIN */}
              {statusHariIni === 'Sakit' || statusHariIni === 'Izin' ? (
                <div className="flex flex-col items-center p-6 text-center max-w-sm">
                  <div className="bg-amber-500/20 p-4 rounded-full mb-3 text-amber-400 border border-amber-500/30">
                    <FileText size={40} />
                  </div>
                  <h3 className="text-white text-base font-black uppercase tracking-wide">Status: {statusHariIni}</h3>
                  <p className="text-slate-400 text-xs mt-1.5 leading-relaxed">
                    Anda telah dideklarasikan **{statusHariIni}** oleh Staff Admin / Piket sekolah hari ini.
                  </p>
                  {keteranganAdmin && (
                    <span className="mt-3 px-3 py-1.5 bg-slate-800 rounded-lg text-slate-300 font-medium text-[11px] block border border-slate-700">
                      Ket: "{keteranganAdmin}"
                    </span>
                  )}
                </div>
              ) : 
              
              /* KONDISI 2: JIKA ABSENSI BERHASIL */
              presensiStatus === 'success' || statusHariIni === 'Hadir' ? (
                <div className="flex flex-col items-center p-4">
                  <div className="bg-emerald-500 p-4 rounded-full mb-3 shadow-md shadow-emerald-200">
                    <CheckCircle2 size={48} className="text-white" />
                  </div>
                  <h3 className="text-white text-base font-black">Data Presensi Masuk Berhasil</h3>
                  <p className="text-slate-400 text-xs mt-1">Status database Anda hari ini: Hadir</p>
                </div>
              ) : 
              
              /* KONDISI 3: PROSES PENGAMBILAN FOTO */
              presensiStatus === 'taking_photo' ? (
                <div className="w-full h-full relative">
                  {!capturedImage ? (
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />
                  ) : (
                    <img src={capturedImage} alt="Preview Jepretan" className="w-full h-full object-cover" />
                  )}
                  <div className="absolute inset-0 border-[16px] border-black/10 pointer-events-none"></div>
                </div>
              ) : 
              
              /* KONDISI 4: IDLE / STANDBY */
              (
                <div className="text-center">
                  <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-3 border border-slate-700">
                    <Camera size={28} className="text-slate-400" />
                  </div>
                  <p className="text-slate-400 text-xs font-medium">Sistem Geofence Siap. Pastikan wajah terlihat jelas.</p>
                </div>
              )}
            </div>

            {/* TOMBOL AKSI KONDISIONAL */}
            <div className="p-5 bg-white flex justify-center gap-3 border-t border-slate-50">
              
              {/* Sembunyikan/Kunci Tombol jika Statusnya Sakit/Izin */}
              {(statusHariIni === 'Sakit' || statusHariIni === 'Izin') ? (
                <div className="text-center text-slate-400 text-xs font-bold flex items-center gap-1.5 py-1">
                  <Info size={14} className="text-amber-500" /> Pengisian kehadiran dikunci otomatis oleh sistem.
                </div>
              ) : (
                <>
                  {!capturedImage && presensiStatus !== 'success' && statusHariIni !== 'Hadir' && (
                    <button 
                      onClick={handlePresensiAction}
                      className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all active:scale-95 shadow-xs"
                    >
                      <Camera size={16} />
                      {presensiStatus === 'idle' ? 'Inisialisasi Kamera' : 'Jepret Foto Wajah'}
                    </button>
                  )}

                  {capturedImage && presensiStatus === 'taking_photo' && (
                    <div className="flex gap-3 w-full max-w-xs">
                      <button onClick={() => setCapturedImage(null)} className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-3.5 rounded-xl text-xs font-black uppercase tracking-wider">Ulangi</button>
                      <button 
                        onClick={submitPresensi}
                        disabled={loading}
                        className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-3.5 rounded-xl text-xs font-black uppercase tracking-wider disabled:opacity-70"
                      >
                        {loading ? <RefreshCw className="animate-spin" size={14} /> : <Navigation size={14} />}
                        {loading ? 'Proses...' : 'Kirim Absen'}
                      </button>
                    </div>
                  )}

                  {(presensiStatus === 'success' || statusHariIni === 'Hadir') && (
                    <button
                      onClick={() => { setCapturedImage(null); setPresensiStatus('idle'); }}
                      className="bg-slate-900 text-white px-6 py-3.5 rounded-xl text-xs font-black uppercase tracking-wider hover:bg-slate-800 transition-all"
                    >
                      Tutup Jendela Sesi
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        {/* STATUS GEOFENCE & LOG RIWAYAT (KANAN) */}
        <div className="space-y-4">
          
          {/* CARD INDIKATOR RADIUS */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
                <MapIcon size={12} /> Kalkulasi Jarak Geofence
              </span>
              <RefreshCw size={12} className={loading ? "animate-spin text-indigo-500" : "text-slate-300"} />
            </div>
            <div className="flex items-baseline gap-1">
              <span className={`text-3xl font-black tracking-tight ${isWithinRadius ? 'text-emerald-600' : 'text-rose-600'}`}>
                {distance.toFixed(1)}
              </span>
              <span className="text-slate-400 text-xs font-bold">meter dari gerbang</span>
            </div>
          </div>

          {/* CARD DATA REAL TIME LOG */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                <Clock size={16} />
              </div>
              <div>
                <p className="text-[9px] uppercase font-bold text-slate-400 leading-none mb-1">Status Hari Ini</p>
                <p className={`text-base font-black ${
                  statusHariIni === 'Hadir' ? 'text-emerald-600' : 
                  statusHariIni === 'Sakit' || statusHariIni === 'Izin' ? 'text-amber-500' : 
                  statusHariIni === 'Alfa' ? 'text-rose-600' : 'text-slate-600'
                }`}>
                  {statusHariIni}
                </p>
              </div>
            </div>
          </div>

          {/* RIWAYAT AKTIVITAS ABSENSI */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs min-h-[280px]">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider mb-4 flex items-center justify-between">
              Log Riwayat Pekan Ini
              <History size={14} className="text-slate-400" />
            </h4>
            
            <div className="space-y-3">
              {history.length > 0 ? history.slice(0, 3).map((item, idx) => (
                <div key={idx} className="flex flex-col p-3.5 rounded-xl bg-slate-50 border border-slate-100 transition-all hover:bg-white hover:shadow-xs">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden border border-gray-200 bg-gray-100 shadow-2xs shrink-0">
                        <img 
                          src={item.foto_bukti || 'https://via.placeholder.com/150?text=No+Photo'}  
                          alt="Bukti Absen" 
                          className="w-full h-full object-cover"
                          onError={(e) => { e.target.src = 'https://via.placeholder.com/150?text=No+Photo' }}
                        />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800">Status: {item.status_kehadiran}</p>
                        <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                          {item.waktu_scan ? new Date(item.waktu_scan).toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit'}) : '--:--'} WIB • {item.tanggal_absen || 'Hari ini'}
                        </p>
                      </div>
                    </div>
                    <ChevronRight size={14} className="text-slate-300" />
                  </div>
                  
                  {item.latitude && item.longitude && (
                    <a 
                      href={`https://www.google.com/maps/search/?api=1&query=${item.latitude},${item.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 py-1.5 bg-white border border-slate-200 rounded-lg text-[9px] font-black text-indigo-600 hover:bg-indigo-50 transition-all uppercase tracking-wider"
                    >
                      <MapPin size={10} /> Konfirmasi Titik Peta
                    </a>
                  )}
                </div>
              )) : (
                <div className="py-12 text-center">
                  <History size={24} className="text-slate-200 mx-auto mb-2" />
                  <p className="text-xs text-slate-400 font-medium">Belum ada riwayat terekam</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

export default ScanPresensiHarian;