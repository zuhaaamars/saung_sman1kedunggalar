import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import {
  User,
  QrCode,
  CheckCircle,
  LogOut,
  Bell
} from 'lucide-react';

const DashboardSiswa = () => {

  const navigate = useNavigate();

  // =========================
  // STATE
  // =========================
  const [user, setUser] = useState(null);

  const [presensi, setPresensi] = useState({
    jam_masuk: null,
    jam_pulang: null,
    status: null
  });

  const [ringkasan, setRingkasan] = useState({
    hadir: 0,
    belum_pulang: 0
  });

  const [presensiMapel, setPresensiMapel] = useState([]);

  const [isLoading, setIsLoading] = useState(true);

  // =========================
  // LOAD DASHBOARD
  // =========================
  useEffect(() => {

    const fetchDashboard = async () => {

      try {

        const token = localStorage.getItem("token");
        const role = localStorage.getItem("user_role");

        // =========================
        // AMBIL USER LOCAL STORAGE
        // =========================
        const storedUser = JSON.parse(
          localStorage.getItem("user") || "null"
        );

        setUser(storedUser);

        // =========================
        // VALIDASI LOGIN
        // =========================
        if (!token || role !== "siswa") {

          localStorage.clear();

          navigate("/login");

          return;
        }

        // =========================
        // REQUEST API
        // =========================
        const response = await axios.get(
          "http://localhost:5001/api/dashboard/siswa",
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        );

        const result = response.data;

        console.log("DASHBOARD SISWA:", result);

        // =========================
        // SIMPAN SISWA ID
        // =========================
        if (result.data?.siswa_id) {

          localStorage.setItem(
            "siswa_id",
            result.data.siswa_id
          );
        }

        // =========================
        // SUCCESS
        // =========================
        if (result.status === "success") {

          setPresensi(
            result.data?.presensi_harian || {
              jam_masuk: null,
              jam_pulang: null,
              status: null
            }
          );

          setRingkasan(
            result.data?.ringkasan || {
              hadir: 0,
              belum_pulang: 0
            }
          );

          setPresensiMapel(
            result.data?.presensi_mapel || []
          );

        } else {

          console.error("Response Error:", result);

        }

      } catch (err) {

        console.error("ERROR DASHBOARD:", err);

        // =========================
        // TOKEN EXPIRED / UNAUTHORIZED
        // =========================
        if (
          err.response?.status === 401 ||
          err.response?.status === 403
        ) {

          localStorage.clear();

          navigate("/login");
        }

      } finally {

        setIsLoading(false);
      }
    };

    fetchDashboard();

  }, [navigate]);

  // =========================
  // FORMAT JAM
  // =========================
  const formatJam = (jam) => {

    if (!jam) return "Belum";

    return jam.slice(0, 5) + " WIB";
  };

  // =========================
  // LOGOUT
  // =========================
  const handleLogout = () => {

    localStorage.clear();

    navigate("/login");
  };

  // =========================
  // LOADING
  // =========================
  if (isLoading) {

    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafc]">

        <div className="h-10 w-10 rounded-full border-4 border-[#0f3d3a] border-t-transparent animate-spin"></div>

      </div>
    );
  }

  return (

    <div className="min-h-screen bg-[#f8fafc] text-slate-800">

      {/* =========================
          TOPBAR
      ========================= */}
      <nav className="fixed top-0 left-64 right-0 h-16 bg-white border-b shadow-sm z-40 flex items-center justify-end px-6">

        <div className="flex items-center gap-4">

          <Bell
            size={20}
            className="text-slate-400"
          />

          <div className="flex items-center gap-3 border-l pl-4">

            <div className="hidden md:block text-right">

              <p className="text-xs text-slate-400">
                Siswa
              </p>

              <p className="text-sm font-bold text-[#0f3d3a]">

                {user?.nama_lengkap ||
                  user?.username ||
                  "Siswa"}

              </p>

            </div>

            <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">

              <User size={20} />

            </div>

            <button
              onClick={handleLogout}
              className="text-red-500 hover:text-red-600 transition"
            >

              <LogOut size={18} />

            </button>

          </div>

        </div>

      </nav>

      {/* =========================
          MAIN
      ========================= */}
      <main className="pt-20 pb-10 px-4 md:px-8 md:ml-64 max-w-7xl">

        {/* =========================
            HERO
        ========================= */}
        <div className="mb-10">

          <h1 className="text-3xl md:text-4xl font-black text-[#0f172a] leading-tight">

            Selamat Datang,
            <br />

            <span className="text-[#0f3d3a]">

              {user?.nama_lengkap ||
                user?.username ||
                "Siswa"}

            </span>

          </h1>

          <p className="mt-2 text-slate-500 font-medium">

            Berikut status presensimu hari ini

          </p>

        </div>

        {/* =========================
            RINGKASAN
        ========================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">

          {/* HADIR */}
          <div className="bg-white border shadow-sm rounded-2xl p-5">

            <p className="text-xs text-slate-400 mb-2">
              Hadir Bulan Ini
            </p>

            <h2 className="text-3xl font-black text-green-600">
              {ringkasan?.hadir || 0}
            </h2>

          </div>

          {/* BELUM PULANG */}
          <div className="bg-white border shadow-sm rounded-2xl p-5">

            <p className="text-xs text-slate-400 mb-2">
              Belum Pulang
            </p>

            <h2 className="text-3xl font-black text-yellow-500">
              {ringkasan?.belum_pulang || 0}
            </h2>

          </div>

        </div>

        {/* =========================
            CONTENT GRID
        ========================= */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

          {/* =========================
              PRESENSI HARIAN
          ========================= */}
          <div className="bg-white rounded-3xl border shadow-sm p-6">

            <div className="flex items-center gap-2 mb-6">

              <QrCode
                size={26}
                className="text-orange-500"
              />

              <h3 className="text-xl font-bold text-[#0f172a]">

                Presensi Harian

              </h3>

            </div>

            <div className="space-y-4">

              {/* MASUK */}
              <div className="flex justify-between items-center bg-slate-50 border rounded-xl p-4">

                <span className="font-medium">
                  Masuk
                </span>

                <span className="font-bold text-green-600">

                  {formatJam(presensi?.jam_masuk)}

                </span>

              </div>

              {/* PULANG */}
              <div className="flex justify-between items-center bg-slate-50 border rounded-xl p-4">

                <span className="font-medium">
                  Pulang
                </span>

                <span className="font-bold text-slate-400">

                  {formatJam(presensi?.jam_pulang)}

                </span>

              </div>

            </div>

          </div>

          {/* =========================
              PRESENSI MAPEL
          ========================= */}
          <div className="bg-white rounded-3xl border shadow-sm p-6 flex flex-col">

            <div className="flex items-center gap-2 mb-6">

              <CheckCircle
                size={26}
                className="text-teal-600"
              />

              <h3 className="text-xl font-bold text-[#0f172a]">

                Presensi Mapel

              </h3>

            </div>

            <div className="border-2 border-dashed rounded-2xl p-4 flex-1 overflow-y-auto">

              {presensiMapel.length === 0 ? (

                <div className="flex flex-col justify-center items-center text-center text-slate-400 h-full py-10">

                  <QrCode
                    size={40}
                    className="mb-3 text-slate-300"
                  />

                  <p>

                    Belum ada aktivitas
                    presensi mapel hari ini

                  </p>

                </div>

              ) : (

                <div className="space-y-3">

                  {presensiMapel.map((item, index) => (

                    <div
                      key={index}
                      className="bg-slate-50 border rounded-xl p-4 flex justify-between items-start"
                    >

                      <div>

                        <h4 className="font-bold text-[#0f172a]">

                          {item?.mapel || "-"}

                        </h4>

                        <p className="text-xs text-slate-400 mt-1">

                          {item?.kelas || "-"}

                        </p>

                        <p className="text-xs text-slate-400">

                          {item?.jam || "-"}

                        </p>

                      </div>

                      <div className="text-right">

                        <p className="text-sm font-bold text-green-600">

                          {formatJam(item?.jam_masuk)}

                        </p>

                        <p className="text-xs text-slate-400 mt-1">

                          {item?.tanggal || "-"}

                        </p>

                      </div>

                    </div>

                  ))}

                </div>

              )}

            </div>

          </div>

        </div>

      </main>

    </div>
  );
};

export default DashboardSiswa;