import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ScanBarcode, MapPin, ArrowRight, CheckCircle2, 
  Sparkles, ShieldAlert, MessageSquare, Camera,
  Mail, Phone, MapPinIcon, Globe
} from 'lucide-react';

const LandingPage = () => {
  const navigate = useNavigate();
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      text: "SAUNG SMANIKE sangat membantu kami dalam memantau kehadiran siswa secara real-time. Orang tua juga merasa lebih tenang karena mendapat notifikasi langsung.",
      name: "Ibu Rina Wulandari",
      role: "Wakil Kepala Sekolah",
    },
    {
      text: "Sistemnya mudah digunakan dan fiturnya lengkap. Titip absen hampir tidak mungkin terjadi lagi.",
      name: "Bapak Andi Pratama",
      role: "Guru Kelas XI",
    }
  ];

  return (
    <div className="min-h-screen bg-[#FDFDFD] font-sans text-[#4A3728] selection:bg-amber-200 selection:text-amber-900 overflow-x-hidden">
      
      {/* --- FIXED NAVBAR --- */}
      <nav className="fixed top-0 inset-x-0 bg-white/90 backdrop-blur-md border-b border-stone-100 z-50 px-6 lg:px-20 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-tr from-[#D97706] to-amber-500 rounded-lg flex items-center justify-center text-white font-black text-sm">
            S
          </div>
          <div>
            <span className="font-black text-sm tracking-tight block text-[#4A3728]">SAUNG SMANIKE</span>
            <span className="text-[9px] font-bold tracking-wider text-amber-600 block -mt-1">Sistem Administrasi Sekolah</span>
          </div>
        </div>
        
        {/* Menu Tengah */}
        <div className="hidden md:flex items-center gap-8 text-xs font-bold uppercase tracking-wider text-[#7C6A5B]">
          {['Beranda', 'Fitur', 'Alur Sistem', 'Tentang', 'Kontak'].map((item) => (
            <a key={item} href={`#${item.toLowerCase().replace(' ', '-')}`} className="hover:text-amber-600 transition-colors">
              {item}
            </a>
          ))}
        </div>

        <div>
          <button 
            onClick={() => navigate('/Login')}
            className="flex items-center gap-1.5 bg-[#D97706] hover:bg-[#B45309] text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-md shadow-amber-600/10"
          >
            Mulai Presensi <ArrowRight size={14} />
          </button>
        </div>
      </nav>

      <main className="w-full pt-16">
        
        {/* --- HERO SECTION --- */}
        <section id="beranda" className="relative max-w-7xl mx-auto px-6 lg:px-20 py-12 lg:py-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Teks Kiri */}
          <div className="lg:col-span-7 relative z-10 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-200/40 rounded-full px-4 py-1 text-xs font-bold text-[#D97706] shadow-sm">
              <Sparkles size={14} /> Presensi Sekolah Generasi Baru
            </div>
            
            <h1 className="text-4xl lg:text-5xl font-black text-[#4A3728] leading-tight tracking-tight">
              Disiplin Lebih Mudah Dengan <span className="text-[#D97706]">Presensi Pintar</span>
            </h1>
            
            <p className="text-sm lg:text-base text-[#7C6A5B] max-w-xl leading-relaxed font-normal">
              SAUNG SMANIKE adalah sistem presensi modern berbasis Geofencing, Selfie AI, dan Barcode yang terintegrasi dengan WhatsApp untuk memudahkan sekolah, guru, dan orang tua.
            </p>

            {/* Pilar Mini Tag Horizontal */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {[
                { icon: <MapPin size={14} />, label: 'Geofencing Akurat' },
                { icon: <Camera size={14} />, label: 'Selfie AI Verification' },
                { icon: <ScanBarcode size={14} />, label: 'Barcode Kelas' },
                { icon: <MessageSquare size={14} />, label: 'WhatsApp Notifikasi' },
              ].map((pill, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-[#FDF8F1] p-2.5 rounded-xl border border-amber-100/50 text-[11px] font-bold text-[#7C6A5B]">
                  <span className="text-[#D97706]">{pill.icon}</span>
                  <span>{pill.label}</span>
                </div>
              ))}
            </div>
            
            <div className="pt-4 flex flex-wrap gap-4">
              <button 
                onClick={() => navigate('/Login')}
                className="group flex items-center gap-2 bg-[#D97706] hover:bg-[#B45309] text-white px-6 py-3.5 rounded-xl font-bold text-sm transition-all shadow-lg shadow-amber-600/20"
              >
                Mulai Presensi <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="bg-white border border-stone-200 text-[#7C6A5B] hover:bg-stone-50 px-6 py-3.5 rounded-xl font-bold text-sm transition-all">
                Lihat Demo
              </button>
            </div>

            <div className="text-xs text-stone-400 flex items-center gap-1.5 pt-2">
              <CheckCircle2 size={14} className="text-emerald-500" /> Terpercaya oleh sekolah untuk presensi yang jujur & transparan.
            </div>
          </div>

          {/* Visual Kanan - Mockup HP Berdasarkan Gambar */}
          <div className="lg:col-span-5 relative flex justify-center lg:justify-end">
            <div className="absolute inset-0 bg-gradient-to-tr from-amber-200 to-emerald-200 rounded-full filter blur-3xl opacity-20 -z-10 transform scale-75"></div>
            <div className="relative border-[6px] border-stone-900 rounded-[2.5rem] overflow-hidden shadow-2xl w-full max-w-[310px] aspect-[9/18] bg-stone-50 p-4 flex flex-col justify-between text-xs">
              
              <div className="space-y-4">
                <div className="text-center font-bold text-[10px] border-b pb-2 text-stone-400 uppercase tracking-wider">SAUNG SMANIKE</div>
                
                <div className="bg-white p-3 rounded-xl border border-stone-200/60 space-y-1">
                  <span className="text-[10px] text-stone-400 font-bold uppercase block">📍 Lokasi Terdeteksi</span>
                  <div className="font-bold text-stone-800">SMA Negeri 1 Kendari</div>
                  <div className="text-emerald-600 font-bold text-[10px]">🟢 Dalam Area Geofence</div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-stone-200/60 space-y-3 flex flex-col items-center">
                  <span className="text-[10px] text-stone-400 font-bold uppercase self-start">📸 Verifikasi Selfie</span>
                  <div className="w-20 h-20 rounded-full bg-stone-100 border-2 border-emerald-500 flex items-center justify-center relative">
                    <span className="text-stone-400 text-[10px]">Siswa Foto</span>
                    <div className="absolute bottom-0 right-0 bg-emerald-500 text-white p-0.5 rounded-full"><CheckCircle2 size={12} /></div>
                  </div>
                </div>
              </div>

              <div className="bg-[#D97706] text-white p-3 rounded-xl text-center font-bold">
                Presensi Berhasil ✓
              </div>
            </div>
          </div>
        </section>

        {/* --- 4 VALUE METRICS SECTION --- */}
        <section className="bg-white border-y border-stone-100 max-w-7xl mx-auto px-6 lg:px-20 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { val: '100%', title: 'Real-time Data', desc: 'Data hadir langsung tersinkron secara real-time.' },
              { val: '0%', title: 'Manipulasi Lokasi', desc: 'Geofencing akurat mencegah siswa titip absen.' },
              { val: 'Langsung', title: 'WhatsApp Alert', desc: 'Orang tua menerima notifikasi kehadiran otomatis.' },
              { val: 'Aman', title: 'Anti-GPS Palsu', desc: 'Sistem mendeteksi fake GPS dan manipulasi lokasi.' },
            ].map((metric, i) => (
              <div key={i} className="text-center space-y-1 border-r last:border-r-0 border-stone-100 px-2">
                <p className="text-2xl lg:text-3xl font-black text-[#D97706]">{metric.val}</p>
                <p className="text-sm font-bold text-[#4A3728]">{metric.title}</p>
                <p className="text-xs text-[#7C6A5B] leading-relaxed">{metric.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* --- 4 FITUR UNGGULAN --- */}
        <section id="fitur" className="max-w-7xl mx-auto px-6 lg:px-20 py-20 space-y-12">
          <div className="text-center space-y-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[#D97706]">Fitur Utama</span>
            <h2 className="text-2xl lg:text-3xl font-black text-[#4A3728]">Teknologi Cerdas untuk Presensi yang Adil dan Akurat</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <MapPin size={20} className="text-amber-600" />,
                title: 'Geofencing & Selfie AI',
                desc: 'Siswa wajib berada di area sekolah dan melakukan verifikasi selfie untuk memastikan kehadiran fisik.',
                bg: 'bg-amber-50/20'
              },
              {
                icon: <ScanBarcode size={20} className="text-emerald-600" />,
                title: 'Dynamic Barcode',
                desc: 'Guru membuat barcode dinamis yang berubah otomatis untuk setiap kelas dan sesi mengajar.',
                bg: 'bg-emerald-50/10'
              },
              {
                icon: <MessageSquare size={20} className="text-blue-600" />,
                title: 'WhatsApp Notification',
                desc: 'Notifikasi otomatis langsung dikirim ke ponsel orang tua saat siswa hadir, terlambat, atau alpa.',
                bg: 'bg-blue-50/20'
              },
              {
                icon: <ShieldAlert size={20} className="text-purple-600" />,
                title: 'Anti-GPS & Security',
                desc: 'Sistem mendeteksi penggunaan fake GPS, perangkat di-root, dan aktivitas kecurangan lainnya.',
                bg: 'bg-purple-50/10'
              }
            ].map((card, idx) => (
              <div key={idx} className={`p-6 rounded-2xl border border-stone-100 flex flex-col justify-between space-y-4 hover:shadow-xl hover:-translate-y-1 transition-all ${card.bg}`}>
                <div className="space-y-3">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm border border-stone-50">
                    {card.icon}
                  </div>
                  <h3 className="text-sm font-bold text-[#4A3728]">{card.title}</h3>
                  <p className="text-xs text-[#7C6A5B] leading-relaxed">{card.desc}</p>
                </div>
                <button className="text-xs font-bold text-stone-500 hover:text-amber-600 flex items-center gap-1 mt-2 self-start transition-colors">
                  Pelajari lebih lanjut <ArrowRight size={12} />
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* --- LINEAR WORKFLOW (HOW IT WORKS) --- */}
        <section id="alur-sistem" className="bg-[#FBF9F6] border-y border-stone-100 py-20">
          <div className="max-w-7xl mx-auto px-6 lg:px-20 space-y-16">
            <div className="text-center space-y-2">
              <span className="text-xs uppercase font-extrabold tracking-widest text-[#D97706]">Alur Sistem</span>
              <h2 className="text-2xl lg:text-3xl font-black text-[#4A3728]">Bagaimana SAUNG SMANIKE Bekerja?</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative">
              {[
                { step: '1', icon: <MapPin size={18} />, title: 'Masuk Area Sekolah', desc: 'Siswa berada dalam radius geofencing yang telah ditetapkan sekolah.' },
                { step: '2', icon: <ScanBarcode size={18} />, title: 'Scan Barcode Kelas', desc: 'Siswa memindai barcode dinamis yang dibuat oleh guru di kelas.' },
                { step: '3', icon: <Camera size={18} />, title: 'Verifikasi Selfie', desc: 'Siswa mengambil foto selfie langsung di tempat untuk validasi fisik AI.' },
                { step: '4', icon: <CheckCircle2 size={18} />, title: 'Presensi Tercatat', desc: 'Presensi sukses, data tersimpan, dan WhatsApp orang tua langsung terkirim.' },
              ].map((flow, index) => (
                <div key={index} className="flex flex-col items-center text-center space-y-2 relative group">
                  <div className="w-12 h-12 bg-white border border-stone-200 rounded-full flex items-center justify-center text-[#D97706] font-bold shadow-sm z-10">
                    {flow.icon}
                  </div>
                  <div className="absolute top-6 left-1/2 w-full h-[1px] border-t border-dashed border-stone-300 hidden lg:block -z-0 group-last:hidden"></div>
                  
                  <h3 className="text-sm font-bold text-[#4A3728] pt-2">{flow.step}. {flow.title}</h3>
                  <p className="text-xs text-[#7C6A5B] max-w-xs leading-relaxed">{flow.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --- STATISTICS & TESTIMONIALS --- */}
        <section id="tentang" className="max-w-7xl mx-auto px-6 lg:px-20 py-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-5 space-y-6">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[#D97706]">Dipercaya Oleh Sekolah</span>
            <h2 className="text-2xl lg:text-3xl font-black text-[#4A3728] leading-tight">Kehadiran Transparan, Kepercayaan Terbangun</h2>
            <p className="text-xs lg:text-sm text-[#7C6A5B] leading-relaxed">
              SAUNG SMANIKE membantu sekolah meningkatkan kedisiplinan ekosistem belajar siswa secara transparan sekaligus mempermudah monitoring berkala.
            </p>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-stone-100">
              <div>
                <p className="text-xl lg:text-2xl font-black text-[#D97706]">500+</p>
                <p className="text-[10px] font-bold text-[#7C6A5B] uppercase tracking-wider">Siswa Aktif</p>
              </div>
              <div>
                <p className="text-xl lg:text-2xl font-black text-[#D97706]">20+</p>
                <p className="text-[10px] font-bold text-[#7C6A5B] uppercase tracking-wider">Guru Aktif</p>
              </div>
              <div>
                <p className="text-xl lg:text-2xl font-black text-[#D97706]">10+</p>
                <p className="text-[10px] font-bold text-[#7C6A5B] uppercase tracking-wider">Kelas Terintegrasi</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {testimonials.map((testi, idx) => (
              <div key={idx} className="bg-[#FDF8F1] p-6 rounded-2xl border border-amber-100/40 space-y-4 flex flex-col justify-between shadow-sm">
                <p className="text-xs italic text-[#7C6A5B] leading-relaxed">“{testi.text}”</p>
                <div className="flex items-center gap-3 pt-2">
                  <div className="w-8 h-8 rounded-full bg-stone-200" />
                  <div>
                    <h4 className="text-xs font-bold text-[#4A3728]">{testi.name}</h4>
                    <p className="text-[10px] text-stone-400 font-medium">{testi.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* --- BOTTOM CTA BANNER --- */}
        <section className="max-w-7xl mx-auto px-6 lg:px-20 pb-16">
          <div className="bg-[#FDF8F1] border border-amber-100/50 rounded-[2rem] p-8 lg:p-12 flex flex-col lg:flex-row justify-between items-center gap-6 shadow-sm">
            <div className="space-y-2 text-center lg:text-left">
              <h2 className="text-xl lg:text-2xl font-black text-[#4A3728]">Siap Mewujudkan Presensi yang Cerdas dan Transparan?</h2>
              <p className="text-xs lg:text-sm text-[#7C6A5B]">Bergabunglah bersama kami untuk memodernisasi pelaporan administrasi sekolah.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <button className="flex items-center gap-2 bg-[#D97706] hover:bg-[#B45309] text-white font-bold text-xs px-5 py-3 rounded-xl transition-all shadow-md">
                Mulai Presensi Sekarang <ArrowRight size={14} />
              </button>
              <button className="bg-white border border-stone-200 text-[#7C6A5B] font-bold text-xs px-5 py-3 rounded-xl transition-all hover:bg-stone-50">
                Hubungi Kami
              </button>
            </div>
          </div>
        </section>

      </main>

      {/* --- FOUR-COLUMN FOOTER --- */}
      <footer id="kontak" className="bg-white border-t border-stone-100 pt-16 pb-8 px-6 lg:px-20 text-xs text-[#7C6A5B]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-stone-100">
          
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-[#D97706] rounded-md flex items-center justify-center text-white font-black text-xs">S</div>
              <span className="font-black text-sm text-[#4A3728]">SAUNG SMANIKE</span>
            </div>
            <p className="leading-relaxed opacity-80 max-w-sm">Solusi presensi modern untuk sekolah yang lebih disiplin, transparan, dan terhubung erat dengan wali murid.</p>
          </div>

          <div className="md:col-span-2 space-y-3">
            <h4 className="font-bold text-[#4A3728] uppercase text-[10px] tracking-wider">Menu</h4>
            <ul className="space-y-2 font-medium">
              {['Beranda', 'Fitur', 'Alur Sistem', 'Tentang', 'Kontak'].map((m) => (
                <li key={m}><a href={`#${m.toLowerCase().replace(' ', '-')}`} className="hover:text-amber-600">{m}</a></li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h4 className="font-bold text-[#4A3728] uppercase text-[10px] tracking-wider">Kontak</h4>
            <ul className="space-y-2 font-medium">
              <li className="flex items-center gap-2"><Mail size={12} className="text-amber-600" /> admin@smanike.sch.id</li>
              <li className="flex items-center gap-2"><Phone size={12} className="text-amber-600" /> 0812-3456-7890</li>
              <li className="flex items-center gap-2"><MapPinIcon size={12} className="text-amber-600 flex-shrink-0" /> SMA Negeri 1 Kendari<br />Jl. Pendidikan No. 1, Kendari</li>
            </ul>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h4 className="font-bold text-[#4A3728] uppercase text-[10px] tracking-wider">Ikuti Kami</h4>
            <div className="flex items-center gap-3 text-stone-400">
              <Globe size={16} className="hover:text-[#D97706] cursor-pointer" />
              <MessageSquare size={16} className="hover:text-[#D97706] cursor-pointer" />
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto pt-6 text-center opacity-60 font-semibold">
          &copy; 2026 SMA Negeri 1 Kendari. All Rights Reserved.
        </div>
      </footer>

    </div>
  );
};

export default LandingPage;