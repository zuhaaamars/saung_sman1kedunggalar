import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';

// Import Komponen
import Navbar from './components/navbar.jsx'; 
import SidebarGuruStaff from './components/Sidebar-gurustaff.jsx';
import SidebarSiswa from './components/Sidebar-siswa.jsx'; 

// Import Pages LOGIN DAN DAFTAR
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';

// Import Pages role SISWA
import DashboardSiswa from './pages/siswa/Dashboard-siswa.jsx'; 
import ScanPresensiHarian from './pages/siswa/PresensiHarian-siswa.jsx';
import ScanPresensiMapel from './pages/siswa/PresensiMapel-siswa.jsx';

// Import Pages
// STAFF
import ImportGuru from './pages/guru_staff/ImportGuru.jsx';
import ImportSiswa from './pages/guru_staff/ImportSiswa.jsx';
import MasterAkademik from './pages/guru_staff/MasterAkademik.jsx';
import JadwalPelajaran from './pages/guru_staff/JadwalPelajaran.jsx';

// GURU
import DashboardGuru from './pages/guru_staff/DashboardGuru.jsx';
import GenerateQRMapel from './pages/guru_staff/GenerateBarcodeMapel.jsx';
import RekapMapel from './pages/guru_staff/RekapMapel.jsx';
import RekapHarian from './pages/guru_staff/RekapHarian.jsx';

// NAVBAR UNTUK LOGIN DAN DAFTAR
const MainLayout = ({ children }) => (
  <>
    <Navbar />
    <div className="min-h-screen">
      {children}
    </div>
  </>
);


// SIDEBAR UNTUK SISWA
const DashboardLayout = ({ children }) => (
  <div className="flex min-h-screen">
    <SidebarSiswa />
    <div className="flex-1 bg-[#f4f4f4]">
      {children}
    </div>
  </div>
);

// SIDEBAR GURU DAN STAFF
const GuruStaffLayout = () => {
  // const token = localStorage.getItem("token");
  // const userRole = localStorage.getItem("user_role");

  // if (!token) return <Navigate to="/Login" replace />;
  // if (userRole !== 'guru' && userRole !== 'staf' && userRole !== 'superadmin') {
  //   return <Navigate to="/Login" replace />;
  // }

  return (
    <div className="flex min-h-screen">
      <SidebarGuruStaff />
      <div className="flex-1 bg-[#f4f4f4] md:ml-64 p-6">
        <Outlet />
      </div>
    </div>
  );
};

// // SIDEBAR UNTUK GURU
// const GuruLayout = ({ children }) => (
//   <div className="flex min-h-screen">
//     <SidebarGuru />
//     <div className="flex-1 bg-[#f4f4f4]">
//       {children}
//     </div>
//   </div>
// );

function App() {
  return (
    <Router>
      <Routes>
        {/* --- PUBLIC ROUTES --- */}
        <Route path="/" element={<MainLayout><LandingPage /></MainLayout>} />
        <Route path="/Login" element={<MainLayout><Login /></MainLayout>} />
        
        {/* --- SISWA ROUTES --- */}
        <Route path="/siswa/Dashboard-siswa" element={<DashboardLayout><DashboardSiswa /></DashboardLayout>} />
        <Route path="/siswa/PresensiHarian-siswa" element={<DashboardLayout><ScanPresensiHarian /></DashboardLayout>} />
        <Route path="/siswa/PresensiMapel-siswa" element={<DashboardLayout><ScanPresensiMapel /></DashboardLayout>} />

        {/*GURU STAFF ROUTES*/}
        <Route element={<GuruStaffLayout />}>
          <Route path="/guru_staff/ImportGuru" element={<ImportGuru />} />
          <Route path="/guru_staff/ImportSiswa" element={<ImportSiswa />} />
          <Route path="/guru_staff/MasterAkademik" element={<MasterAkademik />} />
          <Route path="/guru_staff/JadwalPelajaran" element={<JadwalPelajaran />} />

          <Route path="/guru_staff/DashboardGuru" element={<DashboardGuru />} />
          <Route path="/guru_staff/GenerateBarcodeMapel" element={<GenerateQRMapel />} />
          <Route path="/guru_staff/RekapMapel" element={<RekapMapel />} />
          <Route path="/guru_staff/RekapHarian" element={<RekapHarian />} />
        </Route>

      </Routes>
    </Router>
  );
}

export default App;