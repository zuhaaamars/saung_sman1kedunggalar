import bcrypt

class AdminController:
    @staticmethod
    def generate_password_rumus(nama_lengkap, nomor_induk):
        """
        Rumus: nama depan (lowercase) + 3 digit terakhir nomor induk (NISN/NIP)
        """
        # 1. Ambil nama depan dan ubah ke huruf kecil semua
        nama_depan = nama_lengkap.split()[0].lower()
        
        # 2. Ambil 3 angka terakhir dari nomor induk
        tiga_angka_terakhir = nomor_induk[-3:] if len(nomor_induk) >= 3 else nomor_induk
        
        # 3. Gabungkan menjadi password plain-text
        password_plain = f"{nama_depan}{tiga_angka_terakhir}"
        
        # 4. Enkripsi dengan bcrypt
        salt = bcrypt.gensalt()
        password_hashed = bcrypt.hashpw(password_plain.encode('utf-8'), salt)
        
        return password_plain, password_hashed.decode('utf-8')
        